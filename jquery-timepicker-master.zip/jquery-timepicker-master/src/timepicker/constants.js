const ONE_DAY = 86400;

const EVENT_DEFAULTS = {
  bubbles: true,
  cancelable: false,
  detail: null
};

export { ONE_DAY, EVENT_DEFAULTS };
